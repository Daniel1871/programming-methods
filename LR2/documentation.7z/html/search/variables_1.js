var searchData=
[
  ['color_0',['color',['../class_r_b_node.html#a0877ab978b0055833f3a5266491f1f2e',1,'RBNode']]],
  ['company_5fnumber_1',['company_number',['../class_military.html#ab97350d04dc7cd814548f2a981c13e4e',1,'Military']]]
];
