var searchData=
[
  ['color_0',['Color',['../_r_b_tree_8h.html#ab87bacfdad76e61b9412d7124be44c1c',1,'RBTree.h']]]
];
